# Whisper STT handler
