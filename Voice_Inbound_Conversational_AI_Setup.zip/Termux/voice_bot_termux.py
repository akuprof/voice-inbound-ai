# Termux voice bot script
