#!/data/data/com.termux/files/usr/bin/bash
python voice_bot_termux.py
